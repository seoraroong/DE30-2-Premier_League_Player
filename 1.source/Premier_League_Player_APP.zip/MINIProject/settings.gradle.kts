pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // 필요한 다른 저장소가 있다면 여기에 추가합니다.
    }
}


rootProject.name = "MINIProject"
include(":app")
