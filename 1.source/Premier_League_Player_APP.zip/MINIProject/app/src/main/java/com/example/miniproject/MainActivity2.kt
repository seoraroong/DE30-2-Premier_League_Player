package com.example.miniproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val playerName = intent.getStringExtra("playerName") // 선수 이름 받기
        val playerDetail = intent.getStringExtra("playerDetail") // 선수 상세 정보 받기

        // UI 컴포넌트에 선수 정보 표시
        findViewById<TextView>(R.id.player_name).text = playerName
        findViewById<TextView>(R.id.player_stat).text = playerDetail
        // 버튼 찾기
        val backButton = findViewById<Button>(R.id.back)

        // 버튼 클릭 이벤트 리스너 설정
        backButton.setOnClickListener {
            // 현재 액티비티 종료
            finish()
        }
    }
}
