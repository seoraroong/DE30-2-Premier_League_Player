package com.example.miniproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText // 추가
import java.io.BufferedReader
import java.io.InputStreamReader
import android.content.Context
import android.util.Log

class CsvReader(private val context: Context) {
    private val playerDataMap = mutableMapOf<String, List<String>>()

    init {
        readCsv()
    }

    private fun readCsv() {
        try {
            context.assets.open("project.csv").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                    reader.readLine() // 헤더 줄 건너뛰기
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val tokens = line!!.split(",")
                        if (tokens.size > 1) {
                            playerDataMap[tokens[0].trim()] = tokens
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("CsvReader", "Error reading CSV", e)
        }
    }

    fun findPlayerByName(playerName: String): List<String>? {
        return playerDataMap[playerName.trim()]
    }
}

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val searchEditText = findViewById<TextInputEditText>(R.id.search) // 수정된 부분
        val searchButton = findViewById<Button>(R.id.button)

        searchButton.setOnClickListener {
            val playerName = searchEditText.text.toString().trim() // 수정된 부분: 공백 제거를 위해 trim() 추가
            val playerData = findPlayerByName(playerName)

            if (playerData != null) {
                // 선수 정보를 찾은 경우, 다음 액티비티로 넘어가거나 다른 처리를 수행
                Toast.makeText(this, playerData.joinToString(", "), Toast.LENGTH_LONG).show()

                // 인텐트 생성 및 선수 정보를 다음 액티비티에 전달
                val intent = Intent(this, MainActivity2::class.java).apply {
                    putExtra("playerData", playerData.joinToString(","))
                }
                startActivity(intent)
            } else {

                Toast.makeText(this, "일치하는 선수가 없습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun findPlayerByName(playerName: String): List<String>? {
        try {
            assets.open("project.csv").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        Log.d("CsvReader", "Reading line: $line") // 각 줄 읽기 로그 추가
                        val tokens = line!!.split(",")
                        if (tokens.isNotEmpty() && tokens[1].trim() == playerName.trim()) {
                            return tokens
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("CsvReader", "Error reading CSV", e) // 오류 로깅
            e.printStackTrace()
        }

        return null // 일치하는 선수가 없는 경우 null 반환
    }
}


